module.exports = [
    {
        method: 'GET',
        path: '/',
        handler: (request, h) => {
            return 'Main';
            
        }
    }
];