// ** create-user.component.js ** //

import React, { Component } from 'react';
import axios from 'axios';



 class checkDomain extends Component {

    constructor(props) {
        super(props)

        this.onChangeDomainName = this.onChangeDomainName.bind(this);
        this.onSubmit = this.onSubmit.bind(this);

        this.state = {
            domainName: '',
        }
    }


    onChangeDomainName(e) {
        this.setState({ domainName: e.target.value })
    }

    onSubmit(e) {
        e.preventDefault()
      console.log(this.state.domainName)
        const userObject = {
          
         
          domainName: this.state.domainName,
        };

        // const SOURCE_ARRAY = ['KEYWORD_SPIN', 'EXTENSION'];
        //          const REQUEST_URL = `https://api.ote-godaddy.com/v1/domains/suggest?query=${URL}&sources=${SOURCE_ARRAY}`;
        //          return fetch(REQUEST_URL,{
        //            method: 'GET',
        //            headers: { 'accept': 'application/json', 'Content-Type': 'application/json',
        //            'Authorization' : `sso-key ${GO_DADDY_CLIENT}:${GO_DADDY_SECRET}`}
        //          })
        //           .then(response => response.json())
        //           .then(data => {
        //             console.log("The domain is not availible for purchase. Select from these samples:\n\n" + JSON.stringify(data));
        //             return "The domain is not availible for purchase. Select from these samples:\n\n" + JSON.stringify(data);
        //           })
        // axios.get('http://localhost:3047/checkURL', {
        //     params: {
        //       Domain: 'nick.co m'
        //     }
        //   })
        //   .then(function (response) {
        //     console.log(response);
        //   })
       
      

        axios.post('http://localhost:3063/checkURL', userObject)
        
            .then((res) => {
              console.log(res.data)
            }).catch((error) => {
                console.log(error)
            });
            // (async () => {
            //   const response = await axios.get('http://localhost:3031/checkURL/'+this.state.domainName,userObject)
            //   console.log(response);
            // })()
        this.setState({ domainName: ''})
        console.log(this.state.domainName)
    }


    render() {
        return (
            <div className="wrapper">
                <form onSubmit={this.onSubmit}>
                    <div className="form-group">
                        <label>Enter a Domain:</label>
                        <input type="text" value={this.state.domainName} onChange={this.onChangeDomainName} className="form-control" />
                    </div>
                   
                    <div className="form-group">
                        <input type="submit" value="Check Domain" className="btn btn-success btn-block" />
                    </div>
                </form>
            </div>
        )
    }
}

export default checkDomain;