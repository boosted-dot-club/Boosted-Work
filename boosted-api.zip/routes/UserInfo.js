const pool = require('../db_config.js');

module.exports = [
    {
        // Get all user info
        method: 'GET',
        path: '/UserInfo/users',
        handler: async (request, h) => {

            return new Promise((resolve, reject) => {
                pool.getConnection(function (err, connection) {
                    if (err)
                        throw err;

                    var query_req  = `SELECT * FROM UserInfo`;

                    // Query Database
                    connection.query(query_req, function (error, results, fields) {

                        // When done with the connection, release it.
                        connection.release();

                        // Handle error after the release.
                        if (error)
                            throw error;

                        return resolve(results);
                    });
                });
            })
        }
    }, 
    { 
        // Get user info by User ID
        method: 'GET',
        path: '/UserInfo/user/{user_id}',
        handler: async (request, h) => {
                
            return new Promise((resolve, reject) => {
                pool.getConnection(function (err, connection) {
                    if (err)
                        throw err;

                    var query_req  = `SELECT * FROM UserInfo WHERE user_id = ?`;

                    // Query Database
                    connection.query(query_req, [request.params.user_id] , function (error, results, fields) {

                        // When done with the connection, release it.
                        connection.release();

                        // Handle error after the release.
                        if (error)
                            throw error;

                        return resolve(results);
                    });
                });
            })
        }
    },
    {
        // Delete user info by User ID
        method: 'DELETE',
        path: '/UserInfo/deleteUser/{user_id}',
        handler: async (request, h) => {
                
            return new Promise((resolve, reject) => {
                pool.getConnection(function (err, connection) {
                    if (err)
                        throw err;

                    var query_req  = `DELETE FROM UserInfo WHERE user_id = ?`;

                    // Query Database
                    connection.query(query_req, [request.params.user_id] , function (error, results, fields) {

                        // When done with the connection, release it.
                        connection.release();

                        // Handle error after the release.
                        if (error)
                            throw error;

                        return resolve(`Deleted user with user ID ${request.params.user_id}`);
                    });
                });
            })
        }
    },
    {
        // Create new user info
        method: 'POST',
        path: '/UserInfo/newUser',
        handler: async (request, h) => {
                
            return new Promise((resolve, reject) => {
                pool.getConnection(function (err, connection) {
                    if (err)
                        throw err;
                    
                    var conditions = PostConditions(request.payload);
                    var query_req  = `INSERT INTO UserInfo (${conditions.columns}) VALUES ?`;

                    // Query Database
                    connection.query(query_req, [[conditions.values]], function (error, results, fields) {

                        // When done with the connection, release it.
                        connection.release();

                        // Handle error after the release.
                        if (error)
                            throw error;

                        console.log(results);
                        console.log(fields);

                        return resolve(`New user created`);
                    });
                });
            })
        }
    },
    {
        // Update existing user info
        method: 'PUT',
        path: '/UserInfo/updateUser/{user_id}',
        handler: async (request, h) => {
                
            return new Promise((resolve, reject) => {
                pool.getConnection(function (err, connection) {
                    if (err)
                        throw err;

                    var conditions = PutConditions(request.payload);
                    conditions.values.push(request.params.user_id);

                    var query_req  = `UPDATE UserInfo SET ${conditions.columns} WHERE user_id = ?`;

                    // Query Database
                    connection.query(query_req, conditions.values, function (error, results, fields) {

                        // When done with the connection, release it.
                        connection.release();

                        // Handle error after the release.
                        if (error)
                            throw error;

                        return resolve(`Updated user with user ID ${request.params.user_id}`);
                    });
                });
            })
        }
    }
];

function PostConditions(params) {
    var columns = [
        'first_name',
        'last_name',
        'brand_name',
        'email',
        'phone'
    ];
    var values = [
        params.first_name,
        params.last_name,
        params.brand_name,
        params.email,
        params.phone,
    ];

    // Check if optional fields were filled
    if (params.description != null) {
        columns.push('description');
        values.push(params.description);
    }
  
    if (params.link != null) {
        columns.push('link');
        values.push(params.link);
    }

    if (params.facebook != null) {
        columns.push('facebook');
        values.push(params.facebook);
    }

    if (params.instagram != null) {
        columns.push('instagram');
        values.push(params.instagram);
    }

    if (params.twitter != null) {
        columns.push('twitter');
        values.push(params.twitter);
    }

    if (params.youtube != null) {
        columns.push('youtube');
        values.push(params.youtube);
    }

    if (params.twitch != null) {
        columns.push('twitch');
        values.push(params.twitch);
    }

    if (params.linkedin != null) {
        columns.push('linkedin');
        values.push(params.linkedin);
    }

    if (params.pinterest != null) {
        columns.push('pinterest');
        values.push(params.pinterest);
    }

    if (params.vimeo != null) {
        columns.push('vimeo');
        values.push(params.vimeo);
    }

    if (params.tumblr != null) {
        columns.push('tumblr');
        values.push(params.tumblr);
    }

    if (params.reddit != null) {
        columns.push('reddit');
        values.push(params.reddit);
    }

    if (params.dribble != null) {
        columns.push('dribble');
        values.push(params.dribble);
    }

    return {
      columns: columns,
      values: values
    };
}

function PutConditions(params) {
    var columns = [];
    var values = [];

    // Check which columns to update
    if (params.first_name != null) {
        columns.push('first_name = ?');
        values.push(params.first_name);
    }

    if (params.last_name != null) {
        columns.push('last_name = ?');
        values.push(params.last_name);
    }
  
    if (params.brand_name != null) {
        columns.push('brand_name = ?');
        values.push(params.brand_name);
    }

    if (params.description != null) {
        columns.push('description = ?');
        values.push(params.description);
    }

    if (params.email != null) {
        columns.push('email = ?');
        values.push(params.email);
    }

    if (params.phone != null) {
        columns.push('phone = ?');
        values.push(params.phone);
    }
  
    if (params.link != null) {
        columns.push('link = ?');
        values.push(params.link);
    }

    if (params.facebook != null) {
        columns.push('facebook = ?');
        values.push(params.facebook);
    }

    if (params.instagram != null) {
        columns.push('instagram = ?');
        values.push(params.instagram);
    }

    if (params.twitter != null) {
        columns.push('twitter = ?');
        values.push(params.twitter);
    }

    if (params.youtube != null) {
        columns.push('youtube = ?');
        values.push(params.youtube);
    }

    if (params.twitch != null) {
        columns.push('twitch = ?');
        values.push(params.twitch);
    }

    if (params.linkedin != null) {
        columns.push('linkedin = ?');
        values.push(params.linkedin);
    }

    if (params.pinterest != null) {
        columns.push('pinterest = ?');
        values.push(params.pinterest);
    }

    if (params.vimeo != null) {
        columns.push('vimeo = ?');
        values.push(params.vimeo);
    }

    if (params.tumblr != null) {
        columns.push('tumblr = ?');
        values.push(params.tumblr);
    }

    if (params.reddit != null) {
        columns.push('reddit = ?');
        values.push(params.reddit);
    }

    if (params.dribble != null) {
        columns.push('dribble = ?');
        values.push(params.dribble);
    }

    return {
      columns: columns,
      values: values
    };
}
