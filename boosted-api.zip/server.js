'use strict';

const Hapi = require('@hapi/hapi');
const Routes = require('./routes');

// Define Server
const server = new Hapi.Server({  
    host: 'localhost',
    port: 3063,
    routes: {
        cors: {
            origin: ['*'] // an array of origins or 'ignore'           
        }
    }
});

server.route(Routes);

//server.connection({ routes: { cors: true } })

const launch = async () => {
    try { 
        await server.register({
            plugin: require('hapi-cors'),
            options: {
                origins: ['http://localhost:3001']
            }
        })
 
        await server.start(); 
    } catch (err) { 
        console.error(err); 
        process.exit(1); 
    }; 
    console.log(`Server running at ${server.info.uri}`); 
}

launch();