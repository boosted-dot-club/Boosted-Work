const MySQL = require('mysql');

// Define Database Connection
var pool  = MySQL.createPool({
    connectionLimit : 10,
    host            : '34.86.252.196',
    user            : 'root',
    password        : '',
    database        : 'boosted'
});
  
module.exports = pool;