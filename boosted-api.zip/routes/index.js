var main = require('./main');
var UserConfig = require('./UserConfig');
var UserInfo = require('./UserInfo');
var GoDaddyRoutes = require('./GoDaddyRoutes')
var PayPalRoutes = require('./PayPal Requests.js')

module.exports = [].concat(main, UserConfig, UserInfo, GoDaddyRoutes,PayPalRoutes);
