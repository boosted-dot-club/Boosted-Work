//Routes for GoDaddy API
//const environment = require("../.env");
const fetch = require("node-fetch");

//URLS to make PayPal requets to
const PAYPAL_OAUTH_API = 'https://api.sandbox.paypal.com/v1/oauth2/token/'
const PAYPAL_ORDER_API = 'https://api.sandbox.paypal.com/v2/checkout/orders/';


module.exports = [


    //----------------------------Order API--------------------------------

    //Get approval url
    {
        method: 'POST',
        path: '/getApproval',
        handler: async(request, h) => {

            //Preps data before request to PayPal
            const PAYEE_EMAIL = request.query.PayeeEmail;
            const PAYMENT_AMOUNT = request.query.PaymentAmount;
            const TOKEN = await getToken();

            var dataToSend = {
                'intent': 'CAPTURE',
                'purchase_units': [{
                    'amount': {
                        'currency_code': 'USD',
                        'value': `${PAYMENT_AMOUNT}`
                    }
                }],
                'payee': {
                    'email_address': `${PAYEE_EMAIL}`
                },
                "application_context": {
                    "locale": "en-US",
                    "brand_name": "Boosted",
                    "return_url": "https://www.google.com",
                    "cancel_url": "https://www.google.com",
                    "user_action": "PAY_NOW"
                }
            }


            //Send the order data to the server
            return fetch(PAYPAL_ORDER_API, {
                    method: 'POST',
                    headers: { 'Authorization': `Bearer ${ TOKEN }`, 'Content-Type': 'application/json' },
                    body: JSON.stringify(dataToSend)
                })
                .then(response => response.json())
                .then(data => {
                    captureURL = data.links[1].href;
                    console.log(data);
                    console.log(captureURL);
                    return data;
                })
                .catch(err => console.log(err));
        }
    },

    //captures Payment
    {
        method: 'POST',
        path: '/capture',
        handler: async(request, h) => {

            const TOKEN = await getToken();
            const ORDER_ID = request.query.token;
            const URL = `https://api.sandbox.paypal.com/v2/checkout/orders/${ORDER_ID}/capture`

            return fetch(URL, {
                        method: 'POST',
                        headers: { 'Authorization': `Bearer ${ TOKEN }`, 'Content-Type': 'application/json', 'Prefer': 'return=representation' },

                    }

                )
                .then(response => response.json())
                .then(data => {
                    console.log(data);

                    return data;
                })
                .catch(err => console.log(err));


        }
    },





    //-----------------------Payouts API-------------------------
    //Create Batch payout
    {
        method: 'POST',
        path: '/createPayout',
        handler: async(request, h) => {
            //get client and secret ready to PayPal in exchange for an API Token
            const TOKEN = await getToken();



            const URL = `https://api.sandbox.paypal.com/v1/payments/payouts`
            const BATCH_ID = "Boosted Payment ID: ".concat(Math.floor(Math.random() * (Number.MAX_SAFE_INTEGER - 1) + 1));

            const EMAIL_ADDRESS = request.query.email;
            const SUBJECT = request.query.subject;
            const MESSAGE = request.query.message;
            const PAYMENT_AMOUNT = request.query.amount;
            const PAYMENT_UNIT = request.query.unit;
            const NOTE = request.query.note;
            const PAYMENT_CODE = request.query.code;

            const dataToSend = {
                "sender_batch_header": {
                    "sender_batch_id": `${BATCH_ID}`,
                    "email_subject": `${SUBJECT}`,
                    "email_message": `${MESSAGE}`
                },
                "items": [{
                        "recipient_type": `EMAIL`,
                        "amount": {
                            "value": `${PAYMENT_AMOUNT}`,
                            "currency": `${PAYMENT_UNIT}`
                        },
                        "note": `${NOTE}`,
                        "sender_item_id": `${PAYMENT_CODE}`,
                        "receiver": `${EMAIL_ADDRESS}`
                            /*   "alternate_notification_method": {
                                  "phone": {
                                    "country_code": "91",
                                    "national_number": "9999988888"
                                  }
                                },
                                "notification_language": "fr-FR"*/
                    }

                ]
            }


            return fetch(URL, {
                        method: 'POST',
                        headers: { 'Authorization': `Bearer ${ TOKEN }`, 'Content-Type': 'application/json', 'Prefer': 'return=representation' },
                        body: JSON.stringify(dataToSend)
                    }

                )
                .then(response => response.json())
                .then(data => {
                    console.log(data);
                    return data;
                })
                .catch(err => console.log(err));


        }

    },

    //Shows Payment Details
    {
        method: 'POST',
        path: '/display',
        handler: async(request, h) => {

            const TOKEN = await getToken();
            //requests a token from PayPal


            const BATCH_ID = request.query.batch;
            console.log(BATCH_ID);
            const URL = `https://api.sandbox.paypal.com/v1/payments/payouts/${BATCH_ID}`;


            return fetch(URL, {
                        method: 'GET',
                        headers: { 'Authorization': `Bearer ${ TOKEN }`, 'Content-Type': 'application/json', 'Prefer': 'return=representation' },

                    }

                )
                .then(response => response.json())
                .then(data => {
                    console.log(data);
                    return data;
                })
                .catch(err => console.log(err));


        }
    },

    //Identifies Payout Item Details
    {
        method: 'POST',
        path: '/displayItem',
        handler: async(request, h) => {
            //Uses get for fetch
            const TOKEN = await getToken();

            const ITEM_ID = request.query.item;
            console.log();
            const URL = `https://api.sandbox.paypal.com/v1/payments/payouts-item/${ITEM_ID}`;


            return fetch(URL, {
                        method: 'GET',
                        headers: { 'Authorization': `Bearer ${ TOKEN }`, 'Content-Type': 'application/json', 'Prefer': 'return=representation' },

                    }

                )
                .then(response => response.json())
                .then(data => {
                    console.log(data);
                    return data;
                })
                .catch(err => console.log(err));


        }
    },

    //Cancels unclaimed payout item
    {
        method: 'POST',
        path: '/cancelItem',
        handler: async(request, h) => {
            //Uses post for fetch
            const TOKEN = await getToken();

            const ITEM_ID = request.query.item;
            console.log(ITEM_ID);
            const URL = `https://api.sandbox.paypal.com/v1/payments/payouts-item/${ITEM_ID}/cancel`;
            console.log(URL);


            return fetch(URL, {
                        method: 'POST',
                        headers: { 'Authorization': `Bearer ${ TOKEN }`, 'Content-Type': 'application/json', 'Prefer': 'return=representation' },

                    }

                )
                .then(response => response.json())
                .then(data => {
                    console.log(data);
                    return data;
                })
                .catch(err => console.log(err));


        }


    },


];


//gets token from PayPal
async function getToken() {
    const BASIC_AUTH = Buffer.from(`${ PAYPAL_CLIENT }:${ PAYPAL_SECRET }`).toString('base64');
    let Token
        //requests a token from PayPal
    const TOKEN_PROMISE = fetch(PAYPAL_OAUTH_API, {
            method: 'post',
            headers: { 'accept': 'application/json', 'Authorization': `Basic ${ BASIC_AUTH }`, 'Content-Type': 'application/x-www-form-urlencoded' },
            body: 'grant_type=client_credentials'
        })
        .then(response => response.json())
        .then(data => {
            Token = data.access_token;
            return data;
        })
        .catch(err => console.log(err));
    await TOKEN_PROMISE;
    return Token;
}