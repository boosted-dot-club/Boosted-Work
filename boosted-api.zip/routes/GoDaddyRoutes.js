//Required files

const fetch = require("node-fetch");
const GO_DADDY_CLIENT = '3mM44UbC1kqqoU_9ChibKafnYbT9pPhP1Smzt';
const GO_DADDY_SECRET = 'RjWd37eVqJhQmDDYr9CKxd';


// const env = require("../.env");
// env.config();
// console.log(process.env);

// proxy("/checkURL", {
//   target: "http://localhost:3002/",
//   secure: false,
//   changeOrigin: true
// })
//Routes for GoDaddy API
module.exports = [
    {
      //checks to see if a specific domain is availible for purchase through GoDaddy
        method: 'GET',
        path: '/checkURL',
        //cors: true,
        handler: (request, h) => {

          //gets the URL via query string
          var URL = request.query.URL;

          console.log(JSON.stringify(request));

          //Remove the www. part from the URL if it is there
          URL = stripWWW(URL);

          console.log(url);
          return fetch("https://api.ote-godaddy.com/v1/domains/available",{
            method: 'post',
            body:    JSON.stringify([URL]),
            headers: { 'accept': 'application/json', 'Content-Type': 'application/json',
            'Authorization' : `sso-key ${GO_DADDY_CLIENT}:${GO_DADDY_SECRET}` }
          })
           .then(response => response.json())
           .then(data => {
            console.log("here");
               //If domain is availible return the original data we requested
          if(data.domains != null)
          {
             if(data.domains[0].available){
                 console.log("The domain is availible for purchase\n\n" + JSON.stringify(data));
                 return "The domain is availible for purchase\n\n" + JSON.stringify(data);
               }

               //If domain is unavaible return some suggested URLs
               else if(!data.domains[0].available)
               {
                 const SOURCE_ARRAY = ['KEYWORD_SPIN', 'EXTENSION'];
                 const REQUEST_URL = `https://api.ote-godaddy.com/v1/domains/suggest?query=${URL}&sources=${SOURCE_ARRAY}`;
                 return fetch(REQUEST_URL,{
                   method: 'GET',
                   headers: { 'accept': 'application/json', 'Content-Type': 'application/json',
                   'Authorization' : `sso-key ${GO_DADDY_CLIENT}:${GO_DADDY_SECRET}`}
                 })
                  .then(response => response.json())
                  .then(data => {
                    console.log("The domain is not availible for purchase. Select from these samples:\n\n" + JSON.stringify(data));
                    return "The domain is not availible for purchase. Select from these samples:\n\n" + JSON.stringify(data);
                  })
               }

               //If we get here, PayPal did not return the expected json data. Check the json data that you sent PayPal
              else{
                console.log("An error occured\n\n" + data)
                return "An error occured:\n\n" + data;
              }
            }
            else{
              console.log("URL was not in the proper form. Check the URL that was entered:\n\n" + JSON.stringify(data));
              return "URL was not in the proper form. Check the URL that was entered:\n\n" + JSON.stringify(data);
            }
            
           })
           
           .catch(err => console.log(err));
           
    }
  },

  //Purchase the website
//  {

//  }
];

// module.exports = function(app) {
//   app.use(
//     proxy("/checkURL", {
//       target: "https://http://localhost:3002/",
//       secure: false,
//       changeOrigin: true
//     })
//   );

 
  
//};

//Removes www. from URLs that have it. Leaves URL alone if it has no www. Returns URL
function stripWWW(URL)
{
  var prefixLocation = URL.indexOf('www.');
  if(prefixLocation >= 0)
  {
    URL = URL.substring(prefixLocation+4, URL.length);
  }
  return URL;
}