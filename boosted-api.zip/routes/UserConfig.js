const pool = require('../db_config.js');

module.exports = [
    {
        // Get all user configs
        method: 'GET',
        path: '/UserConfig/users',
        handler: async (request, h) => {

            return new Promise((resolve, reject) => {
                pool.getConnection(function (err, connection) {
                    if (err)
                        throw err;

                    var query_req  = `SELECT * FROM UserConfig`;

                    // Query Database
                    connection.query(query_req, function (error, results, fields) {

                        // When done with the connection, release it.
                        connection.release();

                        // Handle error after the release.
                        if (error)
                            throw error;

                        return resolve(results);
                    });
                });
            })
        }
    }, 
    { 
        // Get user config by user ID
        method: 'GET',
        path: '/UserConfig/user/{user_id}',
        handler: async (request, h) => {
                
            return new Promise((resolve, reject) => {
                pool.getConnection(function (err, connection) {
                    if (err)
                        throw err;

                    var query_req  = `SELECT * FROM UserConfig WHERE user_id = ?`;

                    // Query Database
                    connection.query(query_req, [request.params.user_id] , function (error, results, fields) {

                        // When done with the connection, release it.
                        connection.release();

                        // Handle error after the release.
                        if (error)
                            throw error;

                        return resolve(results);
                    });
                });
            })
        }
    },
    {
        // Delete user config by User ID
        method: 'DELETE',
        path: '/UserConfig/deleteUser/{user_id}',
        handler: async (request, h) => {
                
            return new Promise((resolve, reject) => {
                pool.getConnection(function (err, connection) {
                    if (err)
                        throw err;

                    var query_req  = `DELETE FROM UserConfig WHERE user_id = ?`;

                    // Query Database
                    connection.query(query_req, [request.params.user_id] , function (error, results, fields) {

                        // When done with the connection, release it.
                        connection.release();

                        // Handle error after the release.
                        if (error)
                            throw error;

                        return resolve(`Deleted user config for user with user ID ${request.params.user_id}`);
                    });
                });
            })
        }
    },
    {
        // Create new user config
        method: 'POST',
        path: '/UserConfig/newUser',
        handler: async (request, h) => {
                
            return new Promise((resolve, reject) => {
                pool.getConnection(function (err, connection) {
                    if (err)
                        throw err;
                    
                    var query_req  = `INSERT INTO UserConfig (user_id, template_code, font_code, primary_color_code, secondary_color_code, tertiary_color_code) VALUES ?`;

                    var values = [[
                        request.payload.user_id,
                        request.payload.template_code,
                        request.payload.font_code,
                        request.payload.primary_color_code,
                        request.payload.secondary_color_code,
                        request.payload.tertiary_color_code,
                    ]];

                    // Query Database
                    connection.query(query_req, [values], function (error, results, fields) {

                        // When done with the connection, release it.
                        connection.release();

                        // Handle error after the release.
                        if (error)
                            throw error;

                        return resolve(`New user config created for user with user ID ${request.payload.user_id}`);
                    });
                });
            })
        }
    },
    {
        // Update existing user config by User ID
        method: 'PUT',
        path: '/UserConfig/updateUser/{user_id}',
        handler: async (request, h) => {
                
            return new Promise((resolve, reject) => {
                pool.getConnection(function (err, connection) {
                    if (err)
                        throw err;

                    var conditions = PutConditions(request.payload);
                    conditions.values.push(request.params.user_id);

                    var query_req  = `UPDATE UserConfig SET ${conditions.columns} WHERE user_id = ?`;

                    // Query Database
                    connection.query(query_req, conditions.values, function (error, results, fields) {

                        // When done with the connection, release it.
                        connection.release();

                        // Handle error after the release.
                        if (error)
                            throw error;

                        return resolve(`Updated user config for user with user ID ${request.params.user_id}`);
                    });
                });
            })
        }
    }
];

function PutConditions(params) {
    var columns = [];
    var values = [];

    // Check which columns to update
    if (params.user_id != null) {
        columns.push('user_id = ?');
        values.push(params.user_id);
    }
  
    if (params.template_code != null) {
        columns.push('template_code = ?');
        values.push(params.template_code);
    }

    if (params.font_code != null) {
        columns.push('font_code = ?');
        values.push(params.font_code);
    }

    if (params.primary_color_code != null) {
        columns.push('primary_color_code = ?');
        values.push(params.primary_color_code);
    }

    if (params.secondary_color_code != null) {
        columns.push('secondary_color_code = ?');
        values.push(params.secondary_color_code);
    }
  
    if (params.tertiary_color_code != null) {
        columns.push('tertiary_color_code = ?');
        values.push(params.tertiary_color_code);
    }

    return {
      columns: columns,
      values: values
    };
}